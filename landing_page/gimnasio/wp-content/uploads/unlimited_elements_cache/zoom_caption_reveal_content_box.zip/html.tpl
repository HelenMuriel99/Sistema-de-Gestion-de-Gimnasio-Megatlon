<div id="{{uc_id}}" class="zoom_caption_reveal_content_box" role="region" aria-labelledby="{{caption|ucsafe|raw}}">
  <div class="image-caption-reveal-on-hover">
  </div>

    <div class="icroh-caption">
      {% if show_title == "true" %}<{{title_tag}} class="icroh-title">{{title|raw}}</{{title_tag}}>{% endif %}
      <div class="icroh-text" aria-hidden="true" >{{caption|raw}}</div>
    </div>
  
  {% if enable_link == "true" %}
	  <a href="{{link}}" class="ue-link" {{link_html_attributes|raw}} aria-label="{{caption|ucsafe|raw}}" tabindex="0"></a> 
  {% endif %}	
  
  {% if show_badge == "true" %}
    <div class="ue-badge-wrapper">
      <div class="ue-badge">
        {% if show_badge_icon == "true" %}<span class="ue-badge-icon">{{badge_icon_html|ucsafe|raw}}</span>{% endif %}
        {{badge_text|raw}}
      </div> 
    </div>
  {% endif %}

</div>