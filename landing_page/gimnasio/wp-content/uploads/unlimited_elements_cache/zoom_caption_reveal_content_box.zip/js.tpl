{{ ucfunc("put_docready_start") }}
  
   var objWidget = jQuery("#{{uc_id}}");
  
   var ueCaption = objWidget.find(".icroh-text");
   var showOnBreakpoint = {{show_content_on_breakpoint}};

   function initCaptionRevealContentBox() {  
     
     objWidget.off("mouseenter mouseleave");
     ueCaption.css({height: ""});
     
     if (showOnBreakpoint && window.innerWidth <= {{breakpoint}}) {
       objWidget.addClass("ue_crcb_active");
     } else {
       
       objWidget.on("mouseenter", function() {
           ueCaption.stop(true, false).slideDown({{transition_duration}});
           objWidget.addClass("ue_crcb_active");
       });
       objWidget.on("mouseleave", function() {
           ueCaption.stop(true, false).slideUp({{transition_duration}});
           objWidget.removeClass("ue_crcb_active");
       });
       
     }
   }

  // Initial run
  initCaptionRevealContentBox();

  // Rerun on resize
  jQuery(window).on("resize", function() {
    initCaptionRevealContentBox();
  });
    	
{{ ucfunc("put_docready_end") }}